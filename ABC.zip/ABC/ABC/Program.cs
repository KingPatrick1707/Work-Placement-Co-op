﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    class Program 
    {
        static void Main(string[] args)
        {
            int userInput = 0; string user;
            //Create the following program
            List<CPackage> Deliverys = new List<CPackage>();
            Console.WriteLine(" 1: Create parcels");
            Console.WriteLine(" 2: Display Shipping details");
            Console.WriteLine(" 3: Cost Analysis");
            Console.WriteLine(" 4: Display Couriers details");
            Console.WriteLine(" 5: Exit.");
            user = Console.ReadLine();
            userInput = Convert.ToInt32(user);
            do
            {
                
                switch (userInput)
                {
                    case 1:
                        createAccounts(Deliverys);
                        break;
                    case 2:
                        displayAccounts(Deliverys);
                        break;
                    case 3:
                        displayPercentage(Deliverys);
                        break;
                    case 4:
                        break;
                    default:
                        break;
                }
                Console.WriteLine(" 1: Create parcels");
                Console.WriteLine(" 2: Display Shipping details");
                Console.WriteLine(" 3: Cost Analysis");
                Console.WriteLine(" 4: Display Couriers details");
                Console.WriteLine(" 5: Exit.");
                user = Console.ReadLine();
                userInput = Convert.ToInt32(user);
            } while (userInput != 5);
            
            /*
            Option 1: Create parcels – this option should set up sender and recipient details
            and create a number of two-day and overnight parcel details, have a number of
            over night packages that require couriers*/
            
            /*Option 2: Display Shipping details – This option should display the sender and
            receiver details and shipping cost for each package on the system.
            
            Option 3: Cost Analysis – should give a total of complete shipment costs for all
            shipments and display the % break down of overnight to two-day shipment costs.
            
            Option 4: Display Couriers details – display a list of all couriers required for
            parcell deliveries.
            
            Option 5:Exit.*/
        }
        public static void createAccounts(List<CPackage> cDeliverys)
        {
            double nightFee, flatFee, weight;//sname rname
            string userChoice = "Y", sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip,temp;//only us hese in user inputs if unable to directly use CPackage
            CTwoDayPackage P1 = new CTwoDayPackage("sname", "saddress1", "scity", "sstate", "szip", "rname", "raddress1", "rcity", "rstate", "rzip", 40,15);
            CTwoDayPackage P2 = new CTwoDayPackage("sname", "saddress2", "scity", "sstate", "szip", "rname", "raddress2", "rcity", "rstate", "rzip", 40, 15);
            CTwoDayPackage P3 = new CTwoDayPackage("sname", "saddress3", "scity", "sstate", "szip", "rname", "raddress3", "rcity", "rstate", "rzip", 40, 15);
            CTwoDayPackage P4 = new CTwoDayPackage("sname", "saddress4", "scity", "sstate", "szip", "rname", "raddress4", "rcity", "rstate", "rzip", 40, 15);

            cDeliverys.Add(P1);
            cDeliverys.Add(P2);
            cDeliverys.Add(P3);
            cDeliverys.Add(P4);

            COvernightPackage P5 = new COvernightPackage("sname", "saddress5", "scity", "sstate", "szip", "rname", "raddress5", "rcity", "rstate", "rzip", 40, 15);
            COvernightPackage P6 = new COvernightPackage("sname", "saddress6", "scity", "sstate", "szip", "rname", "saddress6", "rcity", "rstate", "rzip", 40, 15);
            COvernightPackage P7 = new COvernightPackage("sname", "saddress7", "scity", "sstate", "szip", "rname", "saddress7", "rcity", "rstate", "rzip", 40, 15);
            COvernightPackage P8 = new COvernightPackage("sname", "saddress8", "scity", "sstate", "szip", "rname", "saddress8", "rcity", "rstate", "rzip", 40, 15);

            cDeliverys.Add(P5);
            cDeliverys.Add(P6);
            cDeliverys.Add(P7);
            cDeliverys.Add(P8);
            

            //Console.WriteLine("Please enter 1 if you wish to enter additional dilivery's");
            //temp = Console.ReadLine();
            //if (temp == "1")
            //{
            //    do
            //    {
            //        Console.WriteLine("Please enter the Sender's Name");
            //        sname = Console.ReadLine();
            //        Console.WriteLine("Please enter the Sender's Address");
            //        saddress = Console.ReadLine();
            //        Console.WriteLine("Please enter the Sender's home city");
            //        scity = Console.ReadLine();
            //        Console.WriteLine("Please enter the Sender's home state");
            //        sstate = Console.ReadLine();
            //        Console.WriteLine("Please enter the Sender's ZIP code");
            //        szip = Console.ReadLine();
            //        Console.WriteLine("Please enter the Recipient's Name");
            //        rname = Console.ReadLine();
            //        Console.WriteLine("Please enter the Recipient's Address");
            //        raddress = Console.ReadLine();
            //        Console.WriteLine("Please enter the Recipient's home city");
            //        rcity = Console.ReadLine();
            //        Console.WriteLine("Please enter the Recipient's home state");
            //        rstate = Console.ReadLine();
            //        Console.WriteLine("Please enter the Recipient's ZIP code");
            //        rzip = Console.ReadLine();
            //        Console.WriteLine("Please enter the package's weight");
            //        weight = Convert.ToDouble(Console.ReadLine());
            //        Console.WriteLine("Please enter 1 for an overnight package deal and 2 for an two day package deal");
            //        temp = Console.ReadLine();
            //        if (temp == "2")
            //        {
            //            Console.WriteLine("Please enter the package's flatfee");
            //            flatFee = Convert.ToDouble(Console.ReadLine());
            //            if (weight < 0)
            //            {
            //                Console.WriteLine("Error weight cannot be less the zero");
            //                break;
            //            }
            //            CTwoDayPackage PUser = new CTwoDayPackage(sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip, flatFee, weight);
            //            cDeliverys.Add(PUser);
            //        }
            //        else if (temp == "1")
            //        {
            //            Console.WriteLine("Please enter the package's nightfee");
            //            nightFee = Convert.ToDouble(Console.ReadLine());
            //            if (weight < 0)
            //            {
            //                Console.WriteLine("Error weight cannot be less the zero");
            //                break;
            //            }
            //            COvernightPackage PUser = new COvernightPackage(sname, saddress, scity, sstate, szip, rname, raddress, rcity, rstate, rzip, nightFee, weight);
            //            cDeliverys.Add(PUser);
            //        }
            //        else
            //        {
            //            Console.WriteLine("Error in deal selection");
            //            break;
            //        }
            //    } while (userChoice != "N" || userChoice != "n");
            //}    
        }
        public static void displayAccounts(List<CPackage> cDeliverys)
        {
            foreach (CPackage a in cDeliverys)
            {
                string s = a.ShowDetails();
                Console.WriteLine(s);
                //Console.WriteLine(a.ShowDetails());
            }
        }
        public static void displayPercentage(List<CPackage> cPercentage)
        {
            foreach (CPackage a in cPercentage)
            {
                double s = a.Percentage();
                Console.WriteLine(s);
                //Console.WriteLine(a.ShowDetails());
            }
        }
    }
}
