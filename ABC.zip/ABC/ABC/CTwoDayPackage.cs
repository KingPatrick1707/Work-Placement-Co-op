﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    class CTwoDayPackage : CPackage
    {
        /*TwoDayPackage should contain a data member that represents a flat fee that
        the shipping company charges for two-day delivery service. TwoDayPackage
        constructor should receive a value to initialize this data member.
        
        TwoDayPackage should redefine calculateCost so that it computes the shipping
        cost by adding that flat fee to the weight-based cost (calculate by the base class). */
        public double FlatFee, totalCost,percentage;
        
        public CTwoDayPackage(string sname, string saddress, string scity, string sstate, string szip, 
            string rname, string raddress, string rcity, string rstate, string rzip, double flatfee, double weight) : 
            base(sname, saddress,  scity,sstate, szip,
                rname, raddress,  rcity, rstate, rzip)
        {
            FlatFee = flatfee;
            Weight = weight;

        }
        public override double CalculateCost()
        {
            totalCost = base.CalculateCost() + FlatFee;
            return totalCost;
        }
        

        public override string ShowDetails()
        {
            return String.Format("\tSender ID:{0,11} \n\tSender Address:{1,11} \n\tSender City:{2,11} \n\tSender State:{3,11} \n\tSender zip Code:{4,11} \n\tRecipient ID:{5,11} " +
                "\n\tRecipient Address:{6,11} \n\tRecipient City:{7,11} \n\tRecipient State:{8,11} \n\tRecipient zip Code:{9,11} \n\tCost:{10,11}"
                , SenderName, SenderAddress, SenderCity, SenderState, SenderZIP, RecipientName, RecipientAddress, RecipientCity, RecipientState, RecipientZIP, totalCost);
            
        }
        public override double Percentage()
        {
            percentage = (base.CalculateCost() + FlatFee/ base.CalculateCost()) * 100;
            return percentage;
        }
    }


}
