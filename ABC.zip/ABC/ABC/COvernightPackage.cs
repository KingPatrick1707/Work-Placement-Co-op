﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABC
{
    class COvernightPackage : CPackage
    {
        /*OvernightPackage should contain an additional data member representing an
        additional fee per ounce charged for overnight-delivery service.
        OvernightPackage should redefine calculateCost so that it adds the additional
        fee per ounce to the standard cost per ounce before calculating the shipping
        cost. In addition couriers are often used for over night packages, this has the
        effect of doubling the shipping costs, if a courier is required the company name,
        contact person, address, city, state, zip code of the courier should be recorded.*/

        public Double NightFee;
        
        public COvernightPackage(string sname, string saddress, string scity, string sstate, string szip,
            string rname, string raddress, string rcity, string rstate, string rzip, double nightfee, double weight) :
            base(sname, saddress, scity, sstate, szip,
                rname, raddress, rcity, rstate, rzip)
        {
            NightFee = nightfee;
            Weight = weight; ;
        }
        public override double CalculateCost()
        {
            return base.CalculateCost() + NightFee;
        }
           

        public override string ShowDetails()
        {
            return String.Format("\tSender ID:{0,11} \n\tSender Address:{1,11} \n\tSender City:{2,11} \n\tSender State:{3,11} \n\tSender zip Code:{4,11} \n\tRecipient ID:{5,11} \n\tRecipient Address:{6,11} \n\tRecipient City:{7,11} \n\tRecipient State:{8,11} \n\tRecipient zip Code:{9,11} \n", SenderName, SenderAddress, SenderCity, SenderState, SenderZIP, RecipientName, RecipientAddress, RecipientCity, RecipientState, RecipientZIP, Cost);
        }
        public override double Percentage()
        {
            return (base.CalculateCost() + NightFee/ base.CalculateCost()) * 100;

        }
    }
}
