<?php

class MainController extends Controller{
    
        
        private $pageID;
        private $db; 
        private $data; 
        private $session;
        private $userAuthorisation; 
    
	
	function __construct($db, $session){  
           
           $this->data=[];
           $this->session=$session; 
           parent::__construct($this->session->getLoggedIn());
           $this->db=$db;
           
           
           $this->processView(); 
           $this->updateView(); 
           $this->debugInfo();
           
	}
          
        
        public function processView(){
            
            
            
            
            if (isset($_GET['pageID'])){  
                $this->pageID=$_GET['pageID'];
            }
            else{  
                $this->pageID='noPageSelected';  
            }
        }  
        public function updateView(){
            
           if($this->loggedin){       
            $this->userAuthorisation=$this->session->getUserAuthorisation();   
            if($this->userAuthorisation==1){
                
               switch ($this->pageID) {           
                case "home":
                    
                    $home=new Home($this->pageID,$this->session);
                    
                    
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();    
                    $data['stringPanel_1'] =$home->getStringPanel_1(); 
                    $data['stringPanel_2'] =$home->getStringPanel_2();     
                    $data['stringPanel_3'] =$home->getStringPanel_3();       
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $data['panelHead_2']=$home->getPanelHead_2(); 
                    $this->data=$data; 
                    
                    include_once 'views/view_3_panel.php';  
                    break;
                case "administrator":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_1_panel.php';
                    break;
                case "administrator_add":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "administrator_deduct":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "process_administrator_add":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "process_administrator_deduct":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "join_start":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;
                case "poker":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;             
                case "blackjack":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;
                case "logout":
                    
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    $this->loggedin=$guest->getLoggedin();
                    $home=new Home($this->pageID,$this->session);$data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();      
                    $data['stringPanel_1'] =$guest->getStringPanel_1(); 
                    $data['panelHead_1']=$guest->getPanelHead_1();
                    $this->data=$data;
                    
                    include_once 'views/view_1_panel.php'; 
                    break;
                default:
                    $home=new Home($this->pageID,$this->session);
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$home->getStringPanel_1(); 
                    $data['stringPanel_2'] =$home->getStringPanel_2(); 
                    $data['stringPanel_3'] =$home->getStringPanel_3(); 
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_2']=$home->getPanelHead_2();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $this->data=$data;
                    
                    include_once 'views/view_3_panel.php';  
                    break;
            }  
            }
            else if($this->userAuthorisation==2){
               switch ($this->pageID) {           
                case "home":
                    $home=new Home($this->pageID,$this->session);
                    
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav(); 
                    $data['stringPanel_1'] =$home->getStringPanel_1();   
                    $data['stringPanel_2'] =$home->getStringPanel_2(); 
                    $data['stringPanel_3'] =$home->getStringPanel_3();                     
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $data['panelHead_2']=$home->getPanelHead_2(); 
                    $this->data=$data;
                    
                    include_once 'views/view_3_panel.php'; 
                    break;
                case "shop":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "process_shop":
                    $home=new Home($this->pageID,$this->session); 
                    $admin=new Shop($this->pageID,NULL,$this->db,$this->session);
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['panelHead_1']=$admin->getPanelHead_1(); 
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_2']=$admin->getPanelHead_2();
                    $data['stringPanel_2'] =$admin->getStringPanel_2();
                    $this->data=$data;
                    include_once 'views/view_2_panel.php';
                    break;
                case "join_start":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;
                case "poker":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;             
                case "blackjack":
                    $home=new Home($this->pageID,$this->session);
                    $game=new Games($this->pageID,$studentID,$this->db,$this->session); 
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$game->getStringPanel_1();
                    $data['stringPanel_2'] =$game->getStringPanel_2();
                    $data['stringPanel_3'] =$game->getStringPanel_3();
                    $data['panelHead_1']=$game->getPanelHead_1();
                    $data['panelHead_2']=$game->getPanelHead_2();
                    $data['panelHead_3']=$game->getPanelHead_3();
                    $this->data=$data;
                    include_once 'views/view_3_panel.php';
                    break;                                     
                             
                case "logout":
                    
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    $this->loggedin=$guest->getLoggedin();
                    $home=new Home($this->pageID,$this->session);$data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();      
                    $data['stringPanel_1'] =$guest->getStringPanel_1(); 
                    $data['panelHead_1']=$guest->getPanelHead_1();
                    $this->data=$data;
                    
                    include_once 'views/view_1_panel.php'; 
                    break;
                default:
                    $home=new Home($this->pageID,$this->session);
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();
                    $data['stringPanel_1'] =$home->getStringPanel_1(); 
                    $data['stringPanel_2'] =$home->getStringPanel_2(); 
                    $data['stringPanel_3'] =$home->getStringPanel_3(); 
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_2']=$home->getPanelHead_2();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $this->data=$data;
                    
                    include_once 'views/view_3_panel.php';  
                    break;
            }  
            }
            
            else {
                    $home=new Home($this->pageID,$this->session);

                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();     
                    $data['stringPanel_1'] =$home->getStringPanel_1();   
                    $data['stringPanel_2'] =$home->getStringPanel_2();  
                    $data['stringPanel_3'] =$home->getStringPanel_3();
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_2']=$home->getPanelHead_2();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $this->data=$data; 
                    
                    
                    include_once 'views/view_3_panel.php';  
            }        
           }
           else{
            switch ($this->pageID) {
                case 'login':
                    $home=new Home($this->pageID,$this->session);
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();      
                    $data['stringPanel_1'] =$guest->getStringPanel_1();     

                    $data['panelHead_1']=$guest->getPanelHead_1();

                    $this->data=$data;

                    include_once 'views/view_1_panel.php'; 
                    break;               
                  
                   
                case 'login_admin':
                    $home=new Home($this->pageID,$this->session);
                    $admin = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();      
                    $data['stringPanel_1'] =$admin->getStringPanel_1();

                    $data['panelHead_1']=$admin->getPanelHead_1();

                    $this->data=$data;

                    
                    include_once 'views/view_1_panel.php'; 
                    break;   
                case 'process_login':
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    $this->loggedin=$guest->getLoggedin(); 
                    $this->userAuthorisation=$this->session->getUserAuthorisation();
                    $home=new Home($this->pageID,$this->session); 
                    
                    
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();       
                    $data['stringPanel_1'] =$guest->getStringPanel_1(); 
                    $data['panelHead_1']=$guest->getPanelHead_1();
                    $this->data=$data; 

                    include_once 'views/view_1_panel.php'; 
                    break;
                case 'process_login_admin':
                    
                    $admin = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    $this->loggedin=$admin->getLoggedin(); 
                    $this->userAuthorisation=$this->session->getUserAuthorisation();
                    $home=new Home($this->pageID,$this->session); 
                    
                    $data=[];  
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();      
                    $data['stringPanel_1'] =$admin->getStringPanel_1();
                    $data['panelHead_1']=$admin->getPanelHead_1();
                    $this->data=$data;

                    include_once 'views/view_1_panel.php';
                    break;
                case "register":
                    $home=new Home($this->pageID,$this->session); 
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();   
                    $data['stringPanel_1'] =$guest->getStringPanel_1();

                    $data['panelHead_1']=$guest->getPanelHead_1();

                    $this->data=$data;

                    include_once 'views/view_1_panel.php';
                    break;    
                case "process_registration":
                    $home=new Home($this->pageID,$this->session);
                    $guest = new loginGuest($this->pageID, NULL, $this->db,$this->session);
                    
                    $data=[]; 
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();     
                    $data['panelHead_1']=$guest->getPanelHead_1(); 
                    $data['stringPanel_1'] =$guest->getStringPanel_1();
                    $this->data=$data; 
                    
                    include_once 'views/view_1_panel.php';
                    break; 
                default:
                    $home=new Home($this->pageID,$this->session);

                    
                    $data=[];
                    $data['pageTitle']=$home->getPageTitle(); 
                    $data['menuNav']   =$home->getMenuNav();     
                    $data['stringPanel_1'] =$home->getStringPanel_1();     
                    $data['stringPanel_2'] =$home->getStringPanel_2();   
                    $data['stringPanel_3'] =$home->getStringPanel_3();    
                    $data['panelHead_1']=$home->getPanelHead_1();
                    $data['panelHead_2']=$home->getPanelHead_2();
                    $data['panelHead_3']=$home->getPanelHead_3();
                    $this->data=$data; 
                    
                    include_once 'views/view_3_panel.php';  
                    break;
                
            }            
           }      
        } 
        private function debugInfo(){
            if(__DEBUG){
                echo '<!-- The Debug SECTION -->';
                echo '<section style="background-color: #BBBBBB">';
                echo '<div class="container">';
                echo '<h2>Web Application Debug information</h2><br>';
                echo '<h3>Controller (CLASS) properties</h3>';
                echo '$loggedin ='.$this->loggedin.'<br>';
                echo '$pageID   ='.$this->pageID.'<br>';
                echo '$userAuthorisation = '.$this->userAuthorisation.'<br>';
                echo '<h3>Super Global Array</h3>';
                echo '<h4>$_GET Arrays</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_GET as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';

                echo '<h4>$_POST Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_POST as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                echo '<h4>$_COOKIE Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_COOKIE as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                echo '<h4>$_SESSION Array</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($_SESSION as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
 
                echo '<h4>$data Array (data passed to VIEW)</h4>';
                echo '<table class="table table-bordered"><thead><tr><th>KEY</th><th>VALUE</th></tr></thead>';
                foreach($this->data as $key=>$value){echo '<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';}
                echo '</table>';
                
                
                echo '</div>';
                echo '</section>';
            }
        }  
}
