CREATE DATABASE  IF NOT EXISTS `projectdatabase` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `projectdatabase`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: projectdatabase
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_details`
--

DROP TABLE IF EXISTS `admin_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_details` (
  `UserId` varchar(10) NOT NULL,
  `Password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_details`
--

LOCK TABLES `admin_details` WRITE;
/*!40000 ALTER TABLE `admin_details` DISABLE KEYS */;
INSERT INTO `admin_details` VALUES ('AdminLogin','d7c371477925ffc50f2794f5021eb9cb7ea9ecd8');
/*!40000 ALTER TABLE `admin_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chip_data`
--

DROP TABLE IF EXISTS `chip_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chip_data` (
  `UserId` varchar(10) NOT NULL,
  `White` int(11) DEFAULT NULL,
  `Pink` int(11) DEFAULT NULL,
  `Red` int(11) DEFAULT NULL,
  `Blue` int(11) DEFAULT NULL,
  `Green` int(11) DEFAULT NULL,
  `Black` int(11) DEFAULT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chip_data`
--

LOCK TABLES `chip_data` WRITE;
/*!40000 ALTER TABLE `chip_data` DISABLE KEYS */;
INSERT INTO `chip_data` VALUES ('User1',5,510,515,520,525,530),('User2',0,500,500,500,500,500),('User3',505,510,515,520,525,530);
/*!40000 ALTER TABLE `chip_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_details` (
  `UserId` varchar(10) NOT NULL,
  `FirstName` varchar(45) NOT NULL,
  `LastName` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  PRIMARY KEY (`UserId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES ('a00012','paddy','lowe','d7c371477925ffc50f2794f5021eb9cb7ea9ecd8'),('a0013','adrian','newey','d7c371477925ffc50f2794f5021eb9cb7ea9ecd8'),('k00216207','patrick','king','d7c371477925ffc50f2794f5021eb9cb7ea9ecd8'),('User1','Generic','Dude','1234'),('User2','Doctor','Who','2345'),('User3','Keanu','Reaves','3456');
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'projectdatabase'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_deduct_chips_held` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_deduct_chips_held`(IN ID varchar(10),IN min_white int, IN min_pink int,
IN min_red int, IN min_blue int, IN min_green int, IN min_black int)
BEGIN

UPDATE chip_data

SET
White = (White - min_white)
,
Pink = ( Pink - min_pink)
,
Red = ( Red - min_red)
,
Blue = ( Blue - min_blue)
,
Green = (Green - min_green)
,
Black = (Black - min_black)

WHERE UserId = ID;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_game_start_deduction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_game_start_deduction`(IN ID varchar(10))
BEGIN

UPDATE `projectdatabase`.`chip_data`

SET
White = (White - 100)
,
Pink = ( Pink - 100)
,
Red = ( Red - 100)
,
Blue = ( Blue - 100)
,
Green = (Green - 100)
,
Black = (Black - 100)

WHERE UserId = ID;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_chips_held` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_chips_held`(IN ID varchar(10),IN add_white int, IN add_pink int,
IN add_red int, IN add_blue int, IN add_green int, IN add_black int)
BEGIN

UPDATE chip_data

SET
White = (White + add_white)
,
Pink = ( Pink + add_pink)
,
Red = ( Red + add_red)
,
Blue = ( Blue + add_blue)
,
Green = (Green + add_green)
,
Black = (Black + add_black)

WHERE UserId = ID;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_validation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_validation`(IN ID varchar(10),OUT resultString varchar(15))
BEGIN

	DECLARE valid int;
	DECLARE nrWhite int;
    DECLARE nrPink int;
    DECLARE nrRed int;
    DECLARE nrBlue int;
    DECLARE nrGreen int;
    DECLARE nrBlack int;

	SELECT White INTO  nrWhite FROM  chip_data WHERE UserID=ID;
    SELECT Pink INTO  nrPink FROM  chip_data WHERE UserID=ID;
    SELECT Red INTO  nrRed FROM  chip_data WHERE UserID=ID;
    SELECT Blue INTO  nrBlue FROM  chip_data WHERE UserID=ID;
    SELECT Green INTO  nrGreen FROM  chip_data WHERE UserID=ID;
    SELECT Black INTO  nrBlack FROM  chip_data WHERE UserID=ID;

	IF (nrWhite>100||nrPink>100||nrRed>100||nrBlue>100||nrGreen>100||nrBlack>100)
    
	THEN
	   SET resultString='Valid';
       ELSE
       SET resultString='Invalid';
	   END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-24 20:58:33
