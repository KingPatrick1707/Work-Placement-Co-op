<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Card
 *
 * @author pat m'grion
 */
class Card {
    private $suit;
    private $figure;
    public function __construct($Suit, $Fig) {
            $this->suit   = $Suit;
            $this->figure = $Fig;
    }
    public function __toString() {
            return $this->figure . ' of ' . $this->suit;
    }
    public function getFigure() {
            return $this->figure;
    }
    public function getCard() {
            echo $this->figure . " of " . $this->suit . ".<br />";
    }
}
