<?php

class loginGuest extends Model{
    
        private $guestID;
        private $guestFirstName;
        private $guestLastName;
        private $password;   
        
        private $panelHead_1;
        private $stringPanel_1;

        private $db; 
        private $sql;
        private $loginError; 
        private $session; 
        private $pageID;
    
    
	function __construct($pageID,$lecturerID,$db,$session){ 
            $this->session=$session;
            parent::__construct($this->session->getLoggedIn());
            
            $this->guestID=$lecturerID;
            $this->db=$db;
            $this->pageID=$pageID;
            
            $this->setStringPanel_1();
            $this->setPanelHead_1();
	}
        public function setPanelHead_1(){
            switch ($this->pageID) {
                case "login":
                    $this->panelHead_1='<h3>Login</h3>';
                    break;
                case "login_admin":
                    $this->panelHead_1='<h3>Admin Login</h3>';
                    break;
                case "logout":
                    $this->panelHead_1='<h3>Logged out</h3>';
                    break;
                case "process_login":
                    $this->panelHead_1 = '<h3>Home Page of '.$this->guestFirstName.' '.$this->guestLastName.'</h3>';  
                    break;
                case "process_login_admin":
                    $this->panelHead_1 = '<h3>Home Page of '.$this->guestFirstName.' '.$this->guestLastName.'</h3>';  
                    break;
                case "register":
                    $this->panelHead_1='<h3>Register</h3>';
                    break;
                case "process_registration":
                    $this->panelHead_1 = 'Registration Result';  
                    break; 

                default:
                    $this->panelHead_1='<h3>Default</h3>';
                    break;
            }
        }        
        public function setStringPanel_1(){
                
            switch ($this->pageID) {
                case "login":
                    $this->stringPanel_1 = file_get_contents('forms/guestloginform.html');  //this reads an external form file into the string
                    break;
                case "login_admin":
                    $this->stringPanel_1 = file_get_contents('forms/guestloginform.html');  //this reads an external form file into the string
                    break;
                case "register":
                    $this->stringPanel_1 = file_get_contents('forms/registerForm.html');  //this reads an external form file into the string
                    break;
                case "process_login":
                    $this->guestID=$this->db->real_escape_string($_POST['guestID']);
                    $this->password=$this->db->real_escape_string($_POST['guestPass']);
                    if ($this->loginEncryptPW()){ 
                        $this->session->setLoggedin(TRUE);
                        $this->session->setUserAuthorisation(2);
                        $this->session->setUserID($this->guestID);
                        $this->stringPanel_1='Welcome, '.$this->guestFirstName.', to this website.';
                    }
                    else{
                        $this->session->setLoggedin(FALSE); 
                        $this->session->setUserAuthorisation(0);
                        $this->stringPanel_1='Login NOT Successful'.$this->loginError;
                    }
                    break;
                case "process_login_admin":
                    $this->guestID=$this->db->real_escape_string($_POST['guestID']);
                    $this->password=$this->db->real_escape_string($_POST['guestPass']);
                    
                    if ($this->loginEncryptPWAdmin()){
                        $this->session->setLoggedin(TRUE);
                        $this->session->setUserAuthorisation(1);
                        $this->session->setUserID($this->guestID);
                        $this->stringPanel_1='Administrator clearance recognised.';
                    }
                    else{
                        $this->session->setLoggedin(FALSE); 
                        $this->session->setUserAuthorisation(0);
                        $this->stringPanel_1='Login NOT Successful'.$this->loginError;
                    }
                    break; 
                case "process_registration":
                    
                    $this->guestID=$this->db->real_escape_string($_POST['guestID']);
                    $this->guestFirstName=$this->db->real_escape_string($_POST['guestFirstName']);
                    $this->guestLastName=$this->db->real_escape_string($_POST['guestLastName']);
                    $lectPass1=$this->db->real_escape_string($_POST['guestPass1']);
                    $lectPass2=$this->db->real_escape_string($_POST['guestPass2']);
                    if ($lectPass1===$lectPass2){
                        $this->password=$lectPass1;
                        if($this->registerEncryptPW()){ 
                            $this->stringPanel_1 = 'Registration successful - please log in using the link above.';
                            }
                        else{
                            $this->stringPanel_1 = file_get_contents('forms/registerForm.html');
                            $this->stringPanel_1.= 'Unable to complete registration';
                            }                        
                    }
                    else{
                        $this->stringPanel_1 = file_get_contents('forms/registerForm.html');
                        $this->stringPanel_1.= '<br>Passwords you have entered don\'t match - please try again. '; 
                    }                 
                    break; 
                case "logout":
                    $this->logout();
                    $this->stringPanel_1 ='Logged out of your account successfully.<br>Please use the links above to register or login again.';
                    break;
                default:
                    $this->stringPanel_1 = file_get_contents('forms/loginForm.html');
                    break;
            }                                     
        } 
        
        private function logout(){
            $this->loggedin=FALSE;
            $this->session->setLoggedin(FALSE);
            $this->session->setUserAuthorisation(0);           
        }
        private function loginEncryptPW(){
            $this->password=hash('ripemd160', $this->password);
            $sql='SELECT  * FROM user_details WHERE UserId="'.$this->guestID.'" AND Password="'.$this->password.'"';
            $this->sql=$sql;
            if($rs=$this->db->query($sql)){    
                if ($rs->num_rows<>1){
                    $this->loginError= 'Login Fail - '.$rs->num_rows;
                    $rs->free();
                    return FALSE;                    
                }
                else{                    
                $this->loginError= 'Login Successful - no error';
                $row=$rs->fetch_assoc();
                $this->guestID=$row['UserID'];
                $this->guestFirstName=$row['guestFirstName'];
                $this->guestLastName=$row['guestLastName'];
                $rs->free();
                $this->loggedin=TRUE;
                return TRUE;
                } 
            } 
            else{ 
                $this->loggedin=FALSE;
                return FALSE;
            }
        }
        private function registerEncryptPW(){
                        $this->password=hash('ripemd160', $this->password);
                        $sql='INSERT INTO `projectdatabase`.`user_details`(`UserID`,`FirstName`,`LastName`,`Password`)VALUES("'.$this->guestID.'","'.$this->guestFirstName.'","'.$this->guestLastName.'","'.$this->password.'")';
                        if(@$this->db->query($sql)){   
                            return TRUE;
                        } 
                        else{
                            return FALSE;
                        }                        
        }
        private function loginEncryptPWAdmin(){
            $this->password=hash('ripemd160', $this->password);
            $sql='SELECT  * FROM admin_details WHERE UserId="'.$this->guestID.'" AND Password="'.$this->password.'"';
            $this->sql=$sql;
            if($rs=$this->db->query($sql)){    
                if ($rs->num_rows<>1){
                    $this->loginError= 'Login Fail - '.$rs->num_rows;
                    $rs->free();
                    return FALSE;                    
                }
                else{                    
                $this->loginError= 'Login Successful - no error';
                $row=$rs->fetch_assoc();
                $this->guestID=$row['UserID'];
                $this->guestFirstName=$row['guestFirstName'];
                $this->guestLastName=$row['guestLastName'];
                $rs->free();
                $this->loggedin=TRUE;
                return TRUE;
                } 
            } 
            else{ 
                $this->loggedin=FALSE;
                return FALSE;
            }
        }
        
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getLecturerID(){return $this->guestID;}
        public function getSQL(){return $this->sql;}       
        
}
