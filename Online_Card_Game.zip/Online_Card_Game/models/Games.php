<?php
include_once "Deck.php"; 
include_once "Card.php";
include_once "CardDeck.php";
class Games extends Model{
    
        
        private $GameDeck;
        private $P1Card1;
        private $P1Card2;
        private $player1Score;
        private $player2Score;
        private $DCard1;
        private $DCard2;
        private $counter;
        private $score;
        private $P1Hand;
        private $D1Hand;
        private $lectID; 
        
        private $panelHead_1;
        private $stringPanel_1;
        private $panelHead_2;
        private $stringPanel_2;
        private $panelHead_3;
        private $stringPanel_3;
        
        private $db; 
        private $sql;
        private $loginError; 
        private $session; 
        private $pageID;
    
    
	function __construct($pageID,$lecturerID,$db,$session){ 
            $this->session=$session;
            parent::__construct($this->session->getLoggedIn());
            $this->lectID=$lecturerID;
            $this->db=$db;
            $this->pageID=$pageID;
            
            $this->setStringPanel_1();
            $this->setPanelHead_1();
	}
    
        public function setPanelHead_1(){
            switch ($this->pageID) {
                
                case "join_start":
                    $this->panelHead_1='<h3>Welcome</h3>';
                    break;
                case "blackjack":
                    $this->panelHead_1='<h3>Welcome</h3>';
                    break;
                case "poker":
                    $this->panelHead_1='<h3>Welcome</h3>';
                    break;
                default:
                    $this->panelHead_1='<h3>Welcome*</h3>';
                    break;
            }
        }        
        public function setStringPanel_1(){
           
                
            switch ($this->pageID) {
                case "join_start":
                    $this->stringPanel_1 = "";
                    break;
                case "blackjack":
                    $this->stringPanel_1 ="";
                    break;
                case "poker":
                    $this->stringPanel_1 ="";
                    break;
                default:
                    $this->stringPanel_1 ="";
                    break;
            }                                     
        }
         public function setPanelHead_2(){
            switch ($this->pageID) {
                case "join_start":
                    $this->panelHead_2 = "Game Selection";
                    break;
                case "blackjack":
                    $this->panelHead_2 = "Blackjack";
                    break;
                case "poker":
                    $this->panelHead_2 = "Poker";
                    break; 
                default:
                    $this->panelHead_2 = "Game Selection*";
            break;
            }
        }  
        public function setStringPanel_2(){
            switch ($this->pageID) {
                case "join_start":
                    $this->stringPanel_2 = file_get_contents('forms/chooseGameForm.html');
                    break;
                case "blackjack":
                    $sql ="sp_validation()";
                    $this->sql=$sql;
                    if($rs=$this->db->query($sql)){
                        if($rs == "Valid"){
                        $this->stringPanel_2 = 'Enjoy your game.';
                        
                        $this->stringPanel_2 = startGameBlackjack();
                        
                        }
                    }
                    else{$this->stringPanel_2 = 'Game lauch failed.<br>Please make sure you have at 100 of each chip colour.';
                    }
                    break;
                case "poker":
                    $sql ="sp_validation()";
                    $this->sql=$sql;
                    if($rs=$this->db->query($sql)){
                        if($rs == "Valid"){
                        $this->stringPanel_1 = 'Enjoy your game.';
                        $GameDeck = new CardDeck();
                        $GameDeck ->inCardDeck();
                        $GameDeck->shuffleCards();
                        
                        }
                    }
                    else{$this->stringPanel_1 = 'Game lauch failed.<br>Please make sure you have at 100 of each chip colour.';
                    }
                    break; 
                default:
                    $this->stringPanel_1 = file_get_contents('forms/chooseGameForm.html');  //this reads an external form file into the string
            break;
            }
        }          
        public function setPanelHead_3(){
            switch ($this->pageID) {
                case "join_start":
                    $this->panelHead_3='<h3>May the best player win</h3>';
                    break;
                case "blackjack":
                    $this->panelHead_3='<h3>May the best player win</h3>';
                    break;
                case "poker":
                    $this->panelHead_3='<h3>May the best player win</h3>';
                    break;
                default:
                    $this->panelHead_3='<h3>May the best player win*</h3>';
                    break;
            }
        }        
        public function setStringPanel_3(){
            switch ($this->pageID) {
                case "join_start":
                    $this->stringPanel_3 = "";
                    break;
                case "blackjack":
                    $this->stringPanel_3 ="";
                    break;
                case "poker":
                    $this->stringPanel_3 ="";
                    break;
                default:
                    $this->stringPanel_3 ="";
                    break;
            }
        }
        
        private function &startGameBlackjack(){
            $this->GameDeck = new CardDeck();
            $this->GameDeck ->inCardDeck();
            $this->GameDeck->shuffleCards();
            $this->P1Card1  = $this->GameDeck->dealCard();
            $this->P1Card2  = $this->GameDeck->dealCard();
            $this->Player1 = $this->P1Card1 + $this->P1Card2;
            $this->P1Hand = array($this->P1Card1, $this->P1Card2);
            foreach ($card as $this->P1Hand)
                    {
                    $score += $card;
                    }
            
        }
        
        
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getLecturerID(){return $this->lectID;}
        public function getSQL(){return $this->sql;}       
        
}
