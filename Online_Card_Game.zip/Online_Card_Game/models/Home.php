<?php

class Home extends Model{
	
        private $pageTitle;
        private $menuNav;
        private $panelHead_1;
        private $stringPanel_1;
        private $panelHead_2;
        private $stringPanel_2;
        private $panelHead_3;
        private $stringPanel_3;
        private $pageID;
        private $session;
	
	
	function __construct($pageID,$session){   
            $this->session=$session;
            parent::__construct($this->session->getLoggedin());
            
            $this->pageID=$pageID;

            
            $this->setPageTitle();
            $this->setmenuNav();

                
            $this->setPanelHead_1();
            $this->setStringPanel_1();


            
            $this->setPanelHead_2();
            $this->setStringPanel_2();
        
            
            $this->setStringPanel_3();
            $this->setPanelHead_3();
   
	}
        
        
        public function setPageTitle(){
            if($this->loggedin){
                $this->pageTitle='College Online';
            }
            else{        
                $this->pageTitle='College Online';
            }
        }  
        public function setmenuNav(){ 
            
            if($this->loggedin){ 
                if($this->session->getUserAuthorisation()==1){ 
                switch ($this->pageID) {
                    
                    case "home":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "join_start":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "administrator":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "administrator_add":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "administrator_deduct":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "process_administrator_add":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "process_administrator_deduct":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "poker":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "blackjack":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    
                    default:
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=administrator">Administrator</a>';          
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;             
                }                     
                }
                else if($this->session->getUserAuthorisation()==2){
                switch ($this->pageID) {
                    
                    
                    case "home":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "join_start":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "shop":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "process_shop":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "poker":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;
                    case "blackjack":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out</a>';
                        break;                   
                    
                    default:
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home*</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=join_start">Games*</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=shop">Shop*</a>';         
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=logout">Log Out*</a>';
                        break;                  
                }                     
                }
                
                else{  
                    $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                    $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register</a>';
                    $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login</a>';
                }                
            }
            else{ 
                switch ($this->pageID) {
                    case "home":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';//page ID
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login</a>';
                        break;
                    case "register":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login</a>';
                        break;
                    case "login":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Guest Login</a>';
                        $this->menuNav[4]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login_admin">Administrator Login</a>';
                        break;
                    case "login_admin":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[3]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Guest Login</a>';
                        $this->menuNav[4]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login_admin">Administrator Login</a>';
                        break;
                    case "logout":
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login</a>';
                        break; 
                    default:
                        $this->menuNav[0]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=home">Home(Default)</a>';
                        $this->menuNav[1]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=register">Register(Default)</a>';
                        $this->menuNav[2]='<a href="'.$_SERVER['PHP_SELF'].'?pageID=login">Login(Default)</a>';
                        break;
                }
            }
        }   
        public function setPanelHead_1(){
            if($this->loggedin){
                $this->panelHead_1='<h3>Online Game Center</h3>';
            }
            else{        
                $this->panelHead_1='<h3>Online Game Center</h3>';
            }           
            
        }        
        public function setStringPanel_1(){
            if($this->loggedin){
                $this->stringPanel_1='<h4>Overview</h4>';
                $this->stringPanel_1.='<p>Online Game Center is designed to give you the best possibly gaming value for money .'; 
                $this->stringPanel_1.='<p>You are currently logged in.';  
            }
            else{        
                $this->stringPanel_1='<h4>Overview</h4>';
                $this->stringPanel_1.='<p>Online Game Center is designed to give you the best possibly gaming value for money .'; 
                $this->stringPanel_1.='<p>You are NOT logged in. Please register or login using the links above.';  
            } 
        }         
        public function setPanelHead_2(){
            if($this->loggedin){
                $this->panelHead_2='<h3>Welcome</h3>';
            }
            else{        
                $this->panelHead_2='<h3>Please register or login</h3>';
            }
        }  
        public function setStringPanel_2(){
            if($this->loggedin){
                $this->stringPanel_2='Thank you for logging in successfully to the Online Game Center. <br><br>Don\'t forget to logout when you are done.';
            }
            else{        
                $this->stringPanel_2='Please use the link above to login or register.';
            }
        }          
        public function setPanelHead_3(){
            if($this->loggedin){
                $this->panelHead_3='<h3>Side Notes</h3>';
            }
            else{        
                $this->panelHead_3='<h3>Side Notes</h3>';
            } 
        }        
        public function setStringPanel_3(){
            if($this->loggedin){
                $this->stringPanel_3='';
                $this->stringPanel_3.='<p>Online Game Center</p>';
            }
            else{        
                $this->stringPanel_3='';
                $this->stringPanel_3.='<p>Online Game Center</p>';
            } 
        }         
  
        //getters
        public function getPageTitle(){return $this->pageTitle;}
        public function getMenuNav(){return $this->menuNav;}
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getPanelHead_2(){return $this->panelHead_2;}
        public function getStringPanel_2(){return $this->stringPanel_2;}
        public function getPanelHead_3(){return $this->panelHead_3;}
        public function getStringPanel_3(){return $this->stringPanel_3;}
        
        

        
}//end class
        