<?php

class Shop extends Model{
    
        
        private $guestID;   
        
        private $panelHead_1;
        private $stringPanel_1;
        private $panelHead_2;
        private $stringPanel_2;

        private $db; 
        private $sql;
        private $session; 
        private $pageID;
        
        private $white;
        private $pink;
        private $red;
        private $blue;
        private $green;
        private $black;
    
	function __construct($pageID,$lecturerID,$db,$session){ 
            $this->session=$session;
            parent::__construct($this->session->getLoggedIn());
            $this->lectID=$lecturerID;
            $this->db=$db;
            $this->pageID=$pageID;
            
            $this->setStringPanel_1();
            $this->setPanelHead_1();
	}
    
        public function setPanelHead_1(){
            switch ($this->pageID) {
                case "shop":
                    $this->panelHead_1='<h3>Shop</h3>';
                    break;
                case "administrator":
                    $this->panelHead_1='<h3>Administrator</h3>';
                    break;
                case "administrator_add":
                    $this->panelHead_1='<h3>Administrator Add Form</h3>';
                    break;
                case "administrator_deduct":
                    $this->panelHead_1 = '<h3>Administrator Deduct Form</h3>';  
                    break;
                case "process_shop":
                    $this->panelHead_1='<h3>Shop</h3>';
                    break;
                case "process_administrator_add":
                    $this->panelHead_1='<h3>Administrator Add Form</h3>';
                    break;
                case "process_administrator_deduct":
                    $this->panelHead_1 = '<h3>Administrator Deduct Form</h3>';  
                    break;
                default:
                    $this->panelHead_1='<h3>Shop*</h3>';
                    break;
            }
        }        
        public function setStringPanel_1(){
                
            switch ($this->pageID) {
                case "shop":
                    $this->stringPanel_1 = file_get_contents('forms/shop.html');
                    break;
                case "administrator":
                    $this->stringPanel_1 = file_get_contents('forms/chooseAdminForm.html');
                    break;
                case "administrator_add":
                    $this->stringPanel_1 = file_get_contents('forms/adminAddForm.html');  
                    break;
                case "administrator_deduct":
                    $this->stringPanel_1 = file_get_contents('forms/adminDeductForm.html');
                    break;
                case "process_shop":
                    $this->addChipData();
                    $this->stringPanel_1 = file_get_contents('forms/shop.html');
                    break; 
                case "process_administrator_add":
                    $this->addChipData();
                    $this->stringPanel_1 = file_get_contents('forms/adminAddForm.html');
                    break; 
                case "process_administrator_deduct":
                    $this->deductChipData();
                    $this->stringPanel_1 = file_get_contents('forms/adminDeductForm.html');
                    break;
                default:
                    $this->stringPanel_1 = 'Default shop and administrator page.<br>Please report this error.'; 
                    break;
            }                                     
        } 
        public function setPanelHead_2(){
            switch ($this->pageID) {
                case "shop":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;
                case "administrator_add":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;
                case "administrator_deduct":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;
                case "process_shop":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;
                case "process_administrator_add":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;
                case "process_administrator_deduct":
                    $this->panelHead_2='<h3>Chip Quantity of '.$this->guestID.'</h3>';
                    break;  
                 default:
                    $this->panelHead_2='<h3>Chip Quantity</h3>';
                    break;                   
            }         
        } 
        public function setStringPanel_2(){        
            switch ($this->pageID) {
                case "shop":
                    $this->stringPanel_2='';
                    $this->stringPanel_2.='<p>Enter a user ID in the form. Chip Quantity will appear here</p>'; 
                    break;
                case "administrator_add":
                    $this->stringPanel_2='';
                    $this->stringPanel_2.='<p>Enter a user ID in the form. Chip Quantity will appear here</p>'; 
                    break;
                case "process_administrator_deduct":
                    $this->stringPanel_2='';
                    $this->stringPanel_2.='<p>Enter a user ID in the form. Chip Quantity will appear here</p>'; 
                    break;
                case "process_shop":
                    $this->getUserChipDataByID();
                    break;
                case "process_administrator_add":
                    $this->getUserChipDataByID();
                    break;
                case "process_administrator_deduct":
                    $this->getUserChipDataByID();
                    break;
                 default:
                    $this->stringPanel_2='';
                    $this->stringPanel_2.='<p>Enter a user ID in the form. Chip Quantity will appear here<br>Remember if you want your current amount of chips on your account<br>then you must enter your user ID*</p>'; 
                    break;                   
            }           
        }
        private function addChipData(){
                    $this->guestID=$_POST['guestID'];
                    $this->white=$_POST["white"];
                    $this->pink = $_POST["pink"];
                    $this->red=$_POST["red"];
                    $this->blue =$_POST["blue"];
                    $this->green=$_POST["green"];
                    $this->black =$_POST["black"];
    
                    $sql ="sp_update_chips_held(".$this->guestID.'","'.$this->white.'","'.$this->pink.
                            '","'.$this->red.'","'.$this->blue.'","'.$this->green.'","'.$this->black.'")';
                    $this->sql=$sql;
                    if($rs=$this->db->query($sql)){
                    $this->stringPanel_1 = 'Transaction succeaded<br>Please report this error.';
                    }
                    else{$this->stringPanel_1 = 'Transaction failed.<br>Please report this error.';
                    }
        }
        private function deductChipData(){
                    $this->guestID=$_POST['guestID'];
                    $this->white=$_POST["white"];
                    $this->pink = $_POST["pink"];
                    $this->red=$_POST["red"];
                    $this->blue =$_POST["blue"];
                    $this->green=$_POST["green"];
                    $this->black =$_POST["black"];
                    
                    $sql ="sp_deduct_chips_held(".$this->guestID.'","'.$this->white.'","'.$this->pink.
                            '","'.$this->red.'","'.$this->blue.'","'.$this->green.'","'.$this->black.'")';
                    $this->sql=$sql;
                    if($rs=$this->db->query($sql)){
                    $this->stringPanel_1 = 'Deduction succesful.';
                    }
                    else{$this->stringPanel_1 = 'Deduction failed.';
                    }
                    
        }
        private function getUserChipDataByID(){
            $sql='SELECT  White,Pink,Red,Blue,Green,Black FROM chip_data WHERE UserId="'.$this->guestID.'"';
            $this->stringPanel_2='';
            if((@$rs=$this->db->query($sql))&&($rs->num_rows)){
                $this->stringPanel_2.= '<table class="table table-bordered">';
                $this->stringPanel_2.='<tr><th>White</th><th>Pink</th><th>Red</th><th>Blue</th><th>Green</th><th>Black</th></tr>';//table headings
                while ($row = $rs->fetch_assoc()) { 
                        $this->stringPanel_2.='<tr>';
                           foreach($row as $key=>$value){
                                    $this->stringPanel_2.= "<td>$value</td>";
                            }
                            $this->stringPanel_2.= '</tr>';
                        }
                $this->stringPanel_2.= '</table>';   
                }  
            else{ 
                 if (!$rs->num_rows){
                    $this->stringPanel_2.= '<br>No records have been returned - resultset is empty - Nr Rows = '.$rs->num_rows. '<br>';
                    }
                    else{
                    $this->stringPanel_2.= '<br>SQL Query has FAILED - possible problem in the SQL - check for syntax errors<br>';
                    }
            }
            
            $rs->free();
        }
        
        public function getPanelHead_1(){return $this->panelHead_1;}
        public function getStringPanel_1(){return $this->stringPanel_1;}
        public function getLecturerID(){return $this->guestID;}
        public function getSQL(){return $this->sql;}     
        public function getPanelHead_2(){return $this->panelHead_2;}
        public function getStringPanel_2(){return $this->stringPanel_2;}
        
}
