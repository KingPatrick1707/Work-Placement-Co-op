﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btm3_Click(object sender, EventArgs e)
        {
            this.Close(); //removes form from screen

            ListByAge Q3 = new ListByAge();//makes new form called ListByAge
            Q3.ShowDialog();//displays new form
        }

        private void tempLoadData_Click(object sender, EventArgs e)
        {

        }

        private void btm2_Click(object sender, EventArgs e)
        {
            this.Close(); //removes form from screen

            Birthdays Q2 = new Birthdays();//makes new form called ListByAge
            Q2.ShowDialog();//displays new form
        }
    }
}
