﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProjectForm
{
    public class ChildData1: IComparable<ChildData1>
    {
        public string ChildName { get; set; }

        public DateTime DoB { get; set; }

        public string Comment { get; set; }

        public ChildData1(string cname, DateTime dob, string comment)
        {
            ChildName = cname;
            DoB = dob;
            Comment = comment;
        }
        public int CompareTo(ChildData1 C1)
        {
            return String.Compare(this.ChildName, C1.ChildName);
        }
        //public void print()
        //{
        //    Console.WriteLine("*****Child*****");
        //    Console.WriteLine("Name" + ChildName);
        //    Console.WriteLine("Date of Birth" + DoB);
        //    Console.WriteLine("Comment" + Comment);
        //}

        //public DateTime CompareTo(Object obj)
        //{
        //    if (obj is ChildData1)
        //    {
        //        ChildData1 c = obj as ChildData1;
        //        return (this.DoB - c.DoB);
        //    }
        //    else
        //        throw new ArgumentException("Error in compare dates");
        //}

    }
}
