﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectForm
{
    public partial class MonthlyAllowence : Form
    {
        List<ChildData1> DateSort = new List<ChildData1>();
        public MonthlyAllowence()
        {
            InitializeComponent();
        }
        public MonthlyAllowence(List<ChildData1> g)
        {
            InitializeComponent();
            DateSort = g;
        }
        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Hide(); //removes form from screen
            Form1 F1 = new Form1();//makes new form called Form1
            F1.ShowDialog();//displays new form
        }
        private void MonthlyAllowence_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.Columns.Add("Monthly Allowence", 150);
            DateSort.Sort(new ChildCompareDate());
            List<ChildData1> temp = DateSort;
            int single = 0, twin = 0, triplet = 0;
            double totalSingal = 0, totalTwin = 0, totalTriplet = 0,totalMonthlyAllowence = 0;
            string doba1 = "", dobb1 = "", dobc1 = "", doba2 = "", dobb2 = "", dobc2 = "";

            foreach (ChildData1 a in DateSort)
            {
                single++;
                if (a.DoB.ToString("d") == dobb2)
                {
                    triplet++;
                    single--;
                    doba1 = "";
                    dobb1 = "";
                    dobc1 = "";
                    doba2 = "";
                    dobb2 = "";
                    dobc2 = "";
                }
                else if (a.DoB.ToString("d") == dobb1)
                {
                    doba2 = a.ChildName;
                    dobb2 = a.DoB.ToString("d");
                    dobc2 = a.Comment;
                    single--;
                }
                else
                {
                    if (dobb1 == dobb2)
                    {
                        twin++;
                        single--;
                        doba1 = "";
                        dobb1 = "";
                        dobc1 = "";
                        doba2 = "";
                        dobb2 = "";
                        dobc2 = "";
                    }
                    doba1 = a.ChildName;
                    dobb1 = a.DoB.ToString("d");
                    dobc1 = a.Comment;
                }
            }
            totalSingal = 140 * single;
            totalTwin = (140 * 1.5) * single;
            totalTriplet = (140 * 2) * single;
            totalMonthlyAllowence = totalSingal + totalTwin + totalTriplet;
            listView1.Items.Add(Convert.ToString(totalMonthlyAllowence));

        }

    }
}

