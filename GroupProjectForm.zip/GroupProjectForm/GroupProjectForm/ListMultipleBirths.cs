﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectForm
{
    public partial class ListMultipleBirths : Form
    {
        List<ChildData1> DateSort = new List<ChildData1>();
        public ListMultipleBirths()
        {
            InitializeComponent();
        }
        public ListMultipleBirths(List<ChildData1> g)
        {
            InitializeComponent();
            DateSort = g;
        }

        private void btmReturn_Click(object sender, EventArgs e)
        {
            this.Hide(); //removes form from screen
            Form1 F1 = new Form1();//makes new form called Form1
            F1.ShowDialog();//displays new form
        }

        private void ListMultipleBirths_Load(object sender, EventArgs e)
        {
            DisplayMultiplyBirths.View = View.Details;
            DisplayMultiplyBirths.Columns.Add("Name", 150);
            DisplayMultiplyBirths.Columns.Add("Date of Birth", 150);
            DisplayMultiplyBirths.Columns.Add("Comment", 150);
            DateSort.Sort(new ChildCompareDate());
            List<ChildData1> temp = DateSort;
            string doba1 = "", dobb1 = "",dobc1 = "",doba2 = "",dobb2 = "",dobc2 = "";
            String[] tempArray1 = new String[3];
            String[] tempArray2 = new String[3];
            String[] tempArray3 = new String[3];
            foreach (ChildData1 a in DateSort)
            {
                if(a.DoB.ToString("d") == dobb2)
                {
                    tempArray1[0] = doba1;
                    tempArray1[1] = dobb1;
                    tempArray1[2] = dobc1;
                    ListViewItem d = new ListViewItem(tempArray1);
                    DisplayMultiplyBirths.Items.Add(d);
                    tempArray2[0] = doba2;
                    tempArray2[1] = dobb2;
                    tempArray2[2] = dobc2;
                    ListViewItem f = new ListViewItem(tempArray2);
                    DisplayMultiplyBirths.Items.Add(f);
                    tempArray3[0] = a.ChildName;
                    tempArray3[1] = a.DoB.ToString("d");
                    tempArray3[2] = a.Comment;
                    ListViewItem g = new ListViewItem(tempArray3);
                    DisplayMultiplyBirths.Items.Add(g);
                    doba1 = "";
                    dobb1 = "";
                    dobc1 = "";
                    doba2 = "";
                    dobb2 = "";
                    dobc2 = "";
                }
                else if (a.DoB.ToString("d") == dobb1)
                {
                    doba2 = a.ChildName;
                    dobb2 = a.DoB.ToString("d");
                    dobc2 = a.Comment;
                }
                else
                {
                    if (dobb1 == dobb2)
                    {
                        
                        tempArray1[0] = doba1;
                        tempArray1[1] = dobb1;
                        tempArray1[2] = dobc1;
                        ListViewItem d = new ListViewItem(tempArray1);
                        DisplayMultiplyBirths.Items.Add(d);
                        tempArray2[0] = doba2;
                        tempArray2[1] = dobb2;
                        tempArray2[2] = dobc2;
                        ListViewItem f = new ListViewItem(tempArray2);
                        DisplayMultiplyBirths.Items.Add(f);
                        doba1 = "";
                        dobb1 = "";
                        dobc1 = "";
                        doba2 = "";
                        dobb2 = "";
                        dobc2 = "";
                    }
                    doba1 = a.ChildName;
                    dobb1 = a.DoB.ToString("d");
                    dobc1 = a.Comment;
                }
                
            }
        }
    }
}
