﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectForm
{
    public partial class Birthdays : Form
    {
        List<ChildData1> DateSort = new List<ChildData1>();
        public Birthdays()
        {
            InitializeComponent();
        }
        public Birthdays(List<ChildData1> g)
        {
            InitializeComponent();
            DateSort = g;
        }

        private void btmReturn_Click(object sender, EventArgs e)
        {
            this.Hide(); //removes form from screen
            Form1 F1 = new Form1();//makes new form called Form1
            F1.ShowDialog();//displays new form
            
        }

        private void Birthdays_Load(object sender, EventArgs e)
        {
            //List<ChildData1> Date = DateSort; // for list multiply
            DateTime CurrentDay = DateTime.Today;
            DateTime chosenDay = CurrentDay;
            DisplayBirthdays.View = View.Details;
            DisplayBirthdays.Columns.Add("Name", 150);
            DisplayBirthdays.Columns.Add("Date of Birth", 150);
            DisplayBirthdays.Columns.Add("Comment", 150);
            DateSort.Sort(new ChildCompareDate());
            do
            {
                chosenDay = chosenDay.AddDays(1);
                foreach (ChildData1 a in DateSort)
                {
                        if (chosenDay == a.DoB)
                        {
                        String[] tempArray = new String[3];
                        tempArray[0] = a.ChildName;
                        tempArray[0] = a.DoB.ToString("d");
                        tempArray[0] = a.Comment;
                        ListViewItem d = new ListViewItem(tempArray);
                        DisplayBirthdays.Items.Add(d);
                    }
                    }
            } while (count < 8);
                    //ListViewItem d = new ListViewItem(a.ChildName);
                    //DisplayBirthdays.Items.Add(d);
            
        }
    }
}
