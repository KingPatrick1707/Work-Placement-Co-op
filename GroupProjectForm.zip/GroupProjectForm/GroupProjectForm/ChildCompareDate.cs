﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProjectForm
{
     public class ChildCompareDate : IComparer<ChildData1>
    {
        public int Compare(ChildData1 x, ChildData1 y)
        {
            
            return  DateTime.Compare(x.DoB, y.DoB);
            
            
        }
     }
    
}
