﻿namespace GroupProjectForm
{
    partial class ListMultipleBirths
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btmReturn = new System.Windows.Forms.Button();
            this.DisplayMultiplyBirths = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // btmReturn
            // 
            this.btmReturn.Location = new System.Drawing.Point(98, 400);
            this.btmReturn.Name = "btmReturn";
            this.btmReturn.Size = new System.Drawing.Size(100, 43);
            this.btmReturn.TabIndex = 0;
            this.btmReturn.Text = "Main Menu";
            this.btmReturn.UseVisualStyleBackColor = true;
            this.btmReturn.Click += new System.EventHandler(this.btmReturn_Click);
            // 
            // DisplayMultiplyBirths
            // 
            this.DisplayMultiplyBirths.Location = new System.Drawing.Point(50, 12);
            this.DisplayMultiplyBirths.Name = "DisplayMultiplyBirths";
            this.DisplayMultiplyBirths.Size = new System.Drawing.Size(194, 326);
            this.DisplayMultiplyBirths.TabIndex = 1;
            this.DisplayMultiplyBirths.UseCompatibleStateImageBehavior = false;
            // 
            // ListMultipleBirths
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 484);
            this.Controls.Add(this.DisplayMultiplyBirths);
            this.Controls.Add(this.btmReturn);
            this.Name = "ListMultipleBirths";
            this.Text = "ListMultipleBirths";
            this.Load += new System.EventHandler(this.ListMultipleBirths_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btmReturn;
        private System.Windows.Forms.ListView DisplayMultiplyBirths;
    }
}