﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProjectForm
{
    public class ChildCompareString: IComparer<ChildData1>
    {
        public int Compare(ChildData1 x, ChildData1 y)
        {

            return string.Compare(x.ChildName, y.ChildName);


        }
    }
}
