﻿namespace GroupProjectForm
{
    partial class SchoolTimes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReturn = new System.Windows.Forms.Button();
            this.DisplaySchoolTimes = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // btnReturn
            // 
            this.btnReturn.Location = new System.Drawing.Point(91, 400);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(75, 23);
            this.btnReturn.TabIndex = 0;
            this.btnReturn.Text = "Main Menu";
            this.btnReturn.UseVisualStyleBackColor = true;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // DisplaySchoolTimes
            // 
            this.DisplaySchoolTimes.Location = new System.Drawing.Point(58, 39);
            this.DisplaySchoolTimes.Name = "DisplaySchoolTimes";
            this.DisplaySchoolTimes.Size = new System.Drawing.Size(155, 301);
            this.DisplaySchoolTimes.TabIndex = 1;
            this.DisplaySchoolTimes.UseCompatibleStateImageBehavior = false;
            this.DisplaySchoolTimes.SelectedIndexChanged += new System.EventHandler(this.DisplaySchoolTimes_SelectedIndexChanged);
            // 
            // SchoolTimes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 500);
            this.Controls.Add(this.DisplaySchoolTimes);
            this.Controls.Add(this.btnReturn);
            this.Name = "SchoolTimes";
            this.Text = "SchoolTimes";
            this.Load += new System.EventHandler(this.SchoolTimes_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.ListView DisplaySchoolTimes;
    }
}