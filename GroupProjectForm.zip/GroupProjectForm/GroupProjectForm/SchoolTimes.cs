﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProjectForm
{
    public partial class SchoolTimes : Form
    {
        List<ChildData1> DateSort = new List<ChildData1>();
        public SchoolTimes()
        {
            InitializeComponent();
        }
        public SchoolTimes(List<ChildData1> g)
        {
            InitializeComponent();
            DateSort = g;
        }

        private void SchoolTimes_Load(object sender, EventArgs e)
        {
            /*
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = (Convert.ToDateTime(sDate.ToString()));

            String dy = datevalue.Day.ToString();
            String mn = datevalue.Month.ToString();
            String yy = datevalue.Year.ToString();
             */
            String sDate = DateTime.Now.ToString();
            DateTime datevalue = DateTime.Today;
            String Level ="";
            int age;
            String tdy = datevalue.Day.ToString();
            String tmn = datevalue.Month.ToString();
            String ttyy = datevalue.Year.ToString();
            int tdd = Convert.ToInt32(tdy);
            int tmm = Convert.ToInt32(tmn);
            int tyy = Convert.ToInt32(ttyy);
            DisplaySchoolTimes.View = View.Details;
            DisplaySchoolTimes.Columns.Add("Name", 150);
            DisplaySchoolTimes.Columns.Add("Date of Birth", 150);
            DisplaySchoolTimes.Columns.Add("Comment", 150);
            DisplaySchoolTimes.Columns.Add("education", 150);

            foreach (ChildData1 a in DateSort)
            {
                String[] tempArray = new String[3];
                tempArray[0] = a.ChildName;
                tempArray[1] = a.DoB.ToString("d");
                tempArray[2] = a.Comment;
                //int birthYear = Convert.ToInt32(a.DoB.Year);
                age = tyy - Convert.ToInt32(a.DoB.Year);
                if(age < 0)
                {
                    age += 100;
                    if (Convert.ToInt32(a.DoB.Month) >= tmm)
                        age += 1;
                }
                if (age < 5)
                    Level = "Preschool";
                else if (age > 5 && age < 13)
                    Level = "Primary school";
                else if (age > 12 && age < 19)
                    Level = "Secondary School";
                else if (age > 18 && age < 23)
                    Level = "Third Level";
                else if (age < 22)
                    Level = "Finished";
                tempArray[3] = Level;
                ListViewItem d = new ListViewItem(tempArray);
                DisplaySchoolTimes.Items.Add(d);
                
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Hide(); //removes form from screen
            Form1 F1 = new Form1();//makes new form called Form1
            F1.ShowDialog();//displays new form
        }

        private void DisplaySchoolTimes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
