﻿namespace GroupProjectForm
{
    partial class Birthdays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btmReturn = new System.Windows.Forms.Button();
            this.DisplayBirthdays = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // btmReturn
            // 
            this.btmReturn.Location = new System.Drawing.Point(77, 383);
            this.btmReturn.Name = "btmReturn";
            this.btmReturn.Size = new System.Drawing.Size(126, 35);
            this.btmReturn.TabIndex = 0;
            this.btmReturn.Text = "Return to Main Menu";
            this.btmReturn.UseVisualStyleBackColor = true;
            this.btmReturn.Click += new System.EventHandler(this.btmReturn_Click);
            // 
            // DisplayBirthdays
            // 
            this.DisplayBirthdays.Location = new System.Drawing.Point(35, 99);
            this.DisplayBirthdays.Name = "DisplayBirthdays";
            this.DisplayBirthdays.Size = new System.Drawing.Size(206, 145);
            this.DisplayBirthdays.TabIndex = 1;
            this.DisplayBirthdays.UseCompatibleStateImageBehavior = false;
            // 
            // Birthdays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 451);
            this.Controls.Add(this.DisplayBirthdays);
            this.Controls.Add(this.btmReturn);
            this.Name = "Birthdays";
            this.Text = "Birthdays";
            this.Load += new System.EventHandler(this.Birthdays_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btmReturn;
        private System.Windows.Forms.ListView DisplayBirthdays;
    }
}